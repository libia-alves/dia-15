/*module.exports = {
    dialect: 'postgres',
    database: 'taozybhe',
    username: 'taozybhe',
    password: 'pOqRMx252VcAN4knhI6jOM9iS6GSV6bx',
    host: 'silly.db.elephantsql.com',
    port: 5432,
    logging: false
};
 */

module.exports = {
    dialect: 'postgres',
    database: 'projetogestaoveiculos',
    username: 'postgres',
    password: '12345678',
    host: 'localhost',
    port: 5432,
    logging: false
};

